<?php
namespace App\Http\Controllers;
use App\UserData;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;

/**
 * Created by PhpStorm.
 * User: shady
 * Date: 9/3/16
 * Time: 2:26 AM
 */

class IndexController extends Controller {

    public function index(){

       $data=new UserData;
        $result=$data->all();
        return view('index')->with('data',$result);
    }


    public function form()
    {

        return view('create');
    }

    public function save(Request $request)
    {

        $userdata = new UserData();
        $userdata->username = $request->userName;
        $userdata->academyname = $request->academyName;
        $userdata->timeslots = $request->timeSlots;
        $userdata->email = $request->email;
        $userdata->phone = $request->phone;
        $userdata->tags = $request->tags;
        $userdata->description = $request->description;
        $userdata->latitude = $request->latitude;
        $userdata->longitude = $request->longitude;
        if($request->hasFile('image'))
        {
            $file = Input::file('image');
            $name =$file->getClientOriginalName();
            $userdata->images = $name;
            $file->move(public_path().'/uploads/', $name);
        }
        $data=$userdata->save();

        return redirect('user');
    }
    /**
     * Store a newly created resource in storage.
     *
     * @return Response
     */
    public function store()
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function viewUser($id)
    {
        $userdata=new UserData;
        $row=$userdata->where('id',$id)->first();
    return view('profile')->with('row',$row);


    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id)
    {
        $userdata=new UserData;
        $row=$userdata->where('id',$id)->first();

        return view('update')->with('row',$row);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function update(Request $request)
    {
        $userdata = new UserData();
        $post=$request->all();
        $id=$post['id'];
        $data=array(

            'username'=>$post['username'],
            'academyname'=>$post['academyname'],
            'timeslots'=>$post['timeslots'],
            'email'=>$post['email'],
            'phone'=>$post['phone'],
            'tags'=>$post['tags'],
            'description'=>$post['description'],
            'latitude'=>$post['latitude'],
            'longitude'=>$post['longitude']
        );
        $data=$userdata->where('id',$id)->update($data);
        if($data>0)
        {
            return redirect('user')->with('status', 'Record Updated!');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id)
    {
        $userdata=new UserData;
        $result=$userdata->where('id',$id)->delete();

        return redirect('user')->with('status', 'Record Deleted!');

    }
    public function viewmap()
    {
        $userdata=new UserData;
        $result=$userdata->all();
        return view('viewUser')->with('data',$result);
    }

    public function profile()
    {
        $userdata=new UserData;
        $result=$userdata->all();
        return view('profile')->with('data',$result);
    }

    public function demo()
    {
        return view('info');
    }



}
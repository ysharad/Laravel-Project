<?php

/*
|--------------------------------------------------------------------------
| Routes File
|--------------------------------------------------------------------------
|
| Here is where you will register all of the routes in an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/





Route::get('user','IndexController@index');
Route::get('viewUser/{id}','IndexController@viewUser');
Route::get('delete/{id}','IndexController@destroy');
Route::get('newuser', 'IndexController@form');
Route::get('profile', 'IndexController@profile');
Route::post('create','IndexController@save');
Route::get('edit/{id}','IndexController@edit');
Route::post('update','IndexController@update');
Route::get('viewmap','IndexController@viewmap');
Route::get('demo','IndexController@demo');

Route::get('/', function () {
    return view('welcome');
});

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| This route group applies the "web" middleware group to every route
| it contains. The "web" middleware group is defined in your HTTP
| kernel and includes session state, CSRF protection, and more.
|
*/

Route::group(['middleware' => ['web']], function () {
    //
});

<?php
namespace app;
use Illuminate\Database\Eloquent\Model;

class UserData extends Model
{
	protected $table='newusers';

	protected $filltable=['id','username','academyname','timeslots','images','email','phone','tags','description','longitude','latitude'];
	
}
?>
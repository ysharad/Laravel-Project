<?php $__env->startSection('content'); ?>
    <script async defer src="https://maps.googleapis.com/maps/api/js?callback=initMap"></script>
    <div id="map"></div>

    <script type="text/javascript">

        var map;
        function initMap() {
            map = new google.maps.Map(document.getElementById('map'),
                    {

                center: {lat: 28.6353, lng: 77.225},
                zoom: 10
                    });
        }

    </script>
    <?php
    foreach ($data as $row) {
    $id=$row->id;
    $latitude=$row->latitude;
    $longitude=$row->longitude;
    ?>

    <script type="text/javascript">
        var latitude=parseFloat(<?php echo json_encode($latitude); ?>);
        var longitude=parseFloat(<?php echo json_encode($longitude); ?>);
        var id=parseFloat(<?php echo json_encode($id); ?>);

        var marker = new google.maps.Marker({
            id:id,
            position: {lat: latitude, lng: longitude},
            map: map,
            title: user
        });

        marker.setMap(map);

        marker.addListener('click', function() {
            var id = this.get("id");
            window.location.href = "viewUser/"+id;
        });
    </script>


    <?php
    }
    ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
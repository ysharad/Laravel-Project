<?php $__env->startSection('content'); ?>
<p style="color:red"><?php echo(Session::get('message'))?></p>
<a href="<?php echo 'createuser' ?>"><button class="btn btn-primary">Add New User</button></a>


<table id="data-table" class="table table-striped table-bordered nowrap" width="100%">
	<thead>
	<tr>
		<th>UserID</th>
		<th>User Name</th>
		<th>Academy Name</th>
		<th>TimeSlots</th>
		<th>Email</th>
		<th>Phone Number</th>
		<th>Action</th>
	</tr>
	</thead>
	<tbody>
	<?php
	//foreach ($data as $row) {
	?>
	<tr>
		<td><?php //echo($row->id); ?></td>
		<td><?php //echo($row->username); ?></td>
		<td><?php //echo($row->academyname); ?></td>
		<td><?php //echo($row->timeslots); ?></td>
		<td><?php //echo($row->email); ?></td>
		<td><?php //echo($row->phone); ?></td>
		<td>
			<a href="<?php //echo 'ViewUser/'.$row->id?>"><button class="btn btn-primary">View Complete Info</button></a>
			<a href="<?php //echo 'EditUser/'.$row->id?>"><button class="btn btn-primary">Edit</button></a>
			<a href="<?php //echo 'DeleteUser/'.$row->id?>"><button class="btn btn-primary">Delete</button></a>
		</td>
	</tr>
	<?php

	//}
	?>

	</tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
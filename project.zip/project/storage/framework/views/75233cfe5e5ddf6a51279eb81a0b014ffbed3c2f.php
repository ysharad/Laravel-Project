<?php $__env->startSection('content'); ?>

    <h2 class="panel-title">Update User Information</h2>
    </div>
    <div class="panel-body panel-form">
        <form action="<?php echo e(action('IndexController@update')); ?>" method="post"  class="form-horizontal form-bordered" name="demo-form">

            <input type="hidden" name="id" value="<?=$row->id?>">

            <div class="form-group">
                <label class="control-label col-md-4 col-sm-4" for="fullname">Full Name * :</label>
                <div class="col-md-6 col-sm-6">
                    <input class="form-control" type="text" id="fullname" name="username" value="<?php echo($row->username); ?>" placeholder="Required" data-parsley-required="true" />
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-md-4 col-sm-4" for="email">Academy name:</label>
                <div class="col-md-6 col-sm-6">
                    <input class="form-control" type="text" id="email" name="academyname" value="<?php echo($row->academyname); ?>" data-parsley-type="email" placeholder="Email" data-parsley-required="true" />
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-4 col-sm-4" for="email">Timeslots* :</label>
                <div class="col-md-6 col-sm-6">
                    <input class="form-control" type="text" id="email" name="timeslots" value="<?php echo($row->timeslots); ?>" data-parsley-type="email" placeholder="Email" data-parsley-required="true" />
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-4 col-sm-4" for="email">Email * :</label>
                <div class="col-md-6 col-sm-6">
                    <input class="form-control" type="text" id="email" name="email" value="email" data-parsley-type="email" placeholder="Email" data-parsley-required="true" />
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-4 col-sm-4" for="message">Phone :</label>
                <div class="col-md-6 col-sm-6">
                    <input class="form-control" type="text" id="data-phone" name="phone" value="<?php echo($row->phone); ?>" data-parsley-type="number" placeholder="(XXX) XXXX XXX" />
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-4 col-sm-4" for="message">Description (20 chars min, 200 max) :</label>
                <div class="col-md-6 col-sm-6">
                    <textarea class="form-control" id="message" name="description" value="<?php echo($row->description); ?>" rows="4" data-parsley-range="[20,200]" placeholder="Range from 20 - 200"></textarea>
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-md-4 col-sm-4" for="message">Latitude :</label>
                <div class="col-md-6 col-sm-6">
                    <input class="form-control" type="text" id="digits" name="latitude" value="<?php echo($row->latitude); ?>" data-parsley-type="digits" placeholder="Digits" />
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-4 col-sm-4" for="message">Longitude:</label>
                <div class="col-md-6 col-sm-6">
                    <input class="form-control" type="text" id="digits" name="longitude"  value="<?php echo($row->longitude); ?>" data-parsley-type="digits" placeholder="Digits" />
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-4 col-sm-4" for="message">upload Image:</label>
                <div class="col-md-6 col-sm-6">
                    <input class="form-control" type="file"  name="image" data-parsley-type="digits"  />
                </div>
            </div>


            <div class="form-group">
                <label class="control-label col-md-4 col-sm-4"></label>
                <div class="col-md-6 col-sm-6">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </div>
        </form>
    </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>

    <?php

    Mail::raw('Your location was checked recently', function($message)
    {
        $message->to('ysharad.10@gmail.com');
    });
    ?>
<div id="content" class="content">
    <!-- begin breadcrumb -->
    <ol class="breadcrumb pull-right">
        <li><a href="javascript:;">Home</a></li>
        <li><a href="javascript:;">Extra</a></li>
        <li class="active">Profile Page</li>
    </ol>
    <!-- end breadcrumb -->
    <!-- begin page-header -->
    <h1 class="page-header">Profile Page <small>Hello!! I am <?php echo($row->username); ?></small></h1>
    <!-- end page-header -->

    <!-- begin profile-container -->
    <div class="profile-container">
        <!-- begin profile-section -->
        <div class="profile-section">
            <!-- begin profile-left -->
            <div class="profile-left">
                <!-- begin profile-image -->
                <div class="profile-image" >
                    <?php echo"<div><img height='196' width='200' src='../uploads/$row->images'></div>";?>
                    <i class="fa fa-user hide"></i>
                </div>
                <!-- end profile-image -->

                <!-- begin profile-highlight -->

                <!-- end profile-highlight -->
            </div>
            <!-- end profile-left -->
            <!-- begin profile-right -->
            <div class="profile-right">
                <!-- begin profile-info -->
                <div class="profile-info">
                    <!-- begin table -->
                    <div class="table-responsive">
                        <table class="table table-profile">
                            <thead>
                            <tr>
                                <th></th>
                                <th>
                                    <h4><?php echo($row->academyname); ?><small></small></h4>
                                </th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr class="highlight">
                                <td class="field">Name</td>
                                <td><?php echo($row->username); ?></td>
                            </tr>


                            <tr class="highlight">
                                <td class="field">Time Slot</td>
                                <td><?php echo($row->timeslots); ?></td>
                            </tr>
                            <tr class="highlight">
                                <td class="field">email</td>
                                <td><?php echo($row->email); ?></td>
                            </tr>

                            <tr class="highlight">
                                <td class="field">Description</td>
                                <td><?php echo($row->description); ?></td>
                            </tr>

                            <tr class="highlight">
                                <td class="field">Phone</td>
                                <td><?php echo($row->phone); ?></td>
                            </tr>
                            <tr class="highlight">
                                <td class="field">tag</td>
                                <td><a href="#"><?php echo($row->tags); ?></a></td>
                            </tr>
                            <tr class="highlight">
                                <td class="field">Latitude</td>
                                <td><a href="<?php echo($row->latitude); ?>"></a></td>
                            </tr>

                            <tr class="highlight">
                                <td class="field">Longitude</td>
                                <td>
                                    <?php echo($row->longitude); ?>
                                </td>
                            </tr>

                            </tbody>
                        </table>
                    </div>
                    <!-- end table -->
                </div>
                <!-- end profile-info -->
            </div>
            <!-- end profile-right -->
        </div>
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
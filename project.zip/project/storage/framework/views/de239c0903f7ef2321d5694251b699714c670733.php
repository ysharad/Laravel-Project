<?php $__env->startSection('content'); ?>
<p style="color:red"><?php echo(Session::get('message'))?></p>
<a href="<?php echo 'newuser' ?>"><button class="btn btn-primary">Add New User</button></a>
<a href="<?php echo 'viewmap' ?>"><button class="btn btn-primary">Explore</button></a>
<?php if(session('status')): ?>
	<div class="alert alert-success">
		<?php echo e(session('status')); ?>

	</div>
<?php endif; ?>
<hr>
<table id="data-table" class="table table-striped table-bordered nowrap" width="100%">
	<thead>
	<tr>
		<th>Display Pic</th>
		<th>Name</th>
		<th>Academy Name</th>
		<th>TimeSlot</th>
		<th>Email</th>
		<th>Phone Number</th>
		<th>Tags</th>
		<th>Description</th>
		<th></th>
	</tr>
	</thead>
	<tbody>
	<?php
	foreach ($data as $row) {
	?>
	<tr>
		<?php echo($row->id); ?>
		<td><?php echo"<div><img height='50' width='50' alt='No DP' src='../uploads/$row->images'></div>";?></td>
		<td><?php echo($row->username); ?></td>
		<td><?php echo($row->academyname); ?></td>
		<td><?php echo($row->timeslots); ?></td>
		<td><?php echo($row->email); ?></td>
		<td><?php echo($row->phone); ?></td>
		<td><?php echo($row->tags); ?></td>
		<td><?php echo($row->description); ?></td>
		<td>

			<div class="input-group-btn">
				<button type="button" class="btn btn-primary">Action</button>
				<button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
					<span class="caret"></span>
				</button>
				<ul class="dropdown-menu">
					<li><a href="<?php echo 'viewUser/'.$row->id?>">Explore</a></li>
					<li><a style="color:blue" href="<?php echo 'edit/'.$row->id?>">Update</a></li>
					<li class="divider"></li>
					<li><a style="color:red" href="<?php echo 'delete/'.$row->id ?>">Delete</a></li>
				</ul>
			</div>

		</td>
	</tr>
	<?php

	}
	?>

	</tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
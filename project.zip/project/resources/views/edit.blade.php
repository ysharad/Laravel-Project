@extends('welcome')
@section('content')
<html>
<head>
<title>
Add User
</title>
</head>
<body>
    <a href="{{URL::previous()}}"><button class="btn btn-primary"> BACK </button></a><br/><br/>
 <div class="widget">
                <h4 class="widgettitle">Horizontal Form</h4>
                <div class="widgetcontent">
         <form action="{{action('UserController@update')}}" method="post"  class="form-horizontal" role="form">
         	<input type="hidden" name="_token" value="<?= csrf_token();?>">
            <input type="hidden" name="id" value="<?=$row->id?>">

                        <div class="form-group">
                            <label  class="col-md-2 control-label">User Name</label>
                            <div class="col-md-10">
                                <input type="text" class="form-control input-default" placeholder="User Name" name="user_name" value="<?=$row->username?>">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label  class="col-md-2 control-label">Academy Name</label>
                            <div class="col-md-10">
                                <input type="text" class="form-control input-default" placeholder="Academy Name" name="academy_name" value="<?=$row->academyname?>">
                            </div>
                        </div>

                         <div class="form-group">
                            <label  class="col-md-2 control-label">Time Slots</label>
                            <div class="col-md-10">
                                <input type="text" class="form-control input-default" placeholder="Time Slots"  name="time_slots" value="<?=$row->timeslots?>">
                            </div>
                        </div>

                          <div class="form-group">
                            <label  class="col-md-2 control-label">Image</label>
                            <div class="col-md-10">
                                <input type="file" class="form-control input-default"  name="image"value="<?=$row->images?>">
                            </div>
                        </div>


                          <div class="form-group">
                            <label  class="col-md-2 control-label">Email</label>
                            <div class="col-md-10">
                                <input type="email" class="form-control input-default" placeholder="Email"  name="email" value="<?=$row->email?>">
                            </div>
                        </div>

                         <div class="form-group">
                            <label  class="col-md-2 control-label">Phone</label>
                            <div class="col-md-10">
                                <input type="text" class="form-control input-default" placeholder="Phone"  name="phone" value="<?=$row->phone?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label  class="col-md-2 control-label">Tags</label>
                            <div class="col-md-10">
                                <input type="text" class="form-control input-default" placeholder="Tags"  name="tags" value="<?=$row->tags?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label  class="col-md-2 control-label">Description</label>
                            <div class="col-md-10">
                                <textarea class="form-control input-default" placeholder="Description"  name="description" ><?=$row->description?></textarea>
                            </div>
                        </div>

                        <div class="form-group">
                            <label  class="col-md-2 control-label">Latitude</label>
                            <div class="col-md-10">
                                <input type="text" class="form-control input-default" placeholder="Latitude"  name="latitude" value="<?=$row->latitude?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label  class="col-md-2 control-label">Longitude</label>
                            <div class="col-md-10">
                                <input type="text" class="form-control input-default" placeholder="Longitude"  name="longitude" value="<?=$row->longitude?>">
                            </div>
                        </div>
                        
                       
                        <div class="form-group">
                            <div class="col-md-offset-2 col-md-10">
                                <button type="submit" class="btn btn-primary">Update</button>
                            </div>
                        </div>
                    </form>
                </div><!-- widgetcontent-->
            </div><!-- widget-->

            	

		



</body>

</html>

@stop()